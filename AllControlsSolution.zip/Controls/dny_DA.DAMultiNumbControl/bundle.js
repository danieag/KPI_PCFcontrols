/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./MultiNumbControl/index.ts":
/*!***********************************!*\
  !*** ./MultiNumbControl/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DAMultiNumbControl: () => (/* binding */ DAMultiNumbControl)\n/* harmony export */ });\nclass DAMultiNumbControl {\n  constructor() {}\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.MultiNumbControl\";\n    // Primary area\n    var primaryRow = document.createElement(\"div\");\n    primaryRow.className = \"kpi-primary-row\";\n    this._primaryLabel = document.createElement(\"div\");\n    this._primaryLabel.className = \"kpi-primary-label\";\n    this._primaryValue = document.createElement(\"div\");\n    this._primaryValue.className = \"kpi-primary-value\";\n    primaryRow.appendChild(this._primaryLabel);\n    primaryRow.appendChild(this._primaryValue);\n    // Secondary area\n    var secondaryRow = document.createElement(\"div\");\n    secondaryRow.className = \"kpi-secondary-row\";\n    var secondaryItem1 = document.createElement(\"div\");\n    secondaryItem1.className = \"kpi-secondary-item\";\n    this._secondary1Value = document.createElement(\"div\");\n    this._secondary1Value.className = \"kpi-secondary-value\";\n    this._secondary1Label = document.createElement(\"div\");\n    this._secondary1Label.className = \"kpi-secondary-label\";\n    secondaryItem1.appendChild(this._secondary1Value);\n    secondaryItem1.appendChild(this._secondary1Label);\n    var secondaryItem2 = document.createElement(\"div\");\n    secondaryItem2.className = \"kpi-secondary-item\";\n    this._secondary2Value = document.createElement(\"div\");\n    this._secondary2Value.className = \"kpi-secondary-value\";\n    this._secondary2Label = document.createElement(\"div\");\n    this._secondary2Label.className = \"kpi-secondary-label\";\n    secondaryItem2.appendChild(this._secondary2Value);\n    secondaryItem2.appendChild(this._secondary2Label);\n    secondaryRow.appendChild(secondaryItem1);\n    secondaryRow.appendChild(secondaryItem2);\n    this._root.appendChild(primaryRow);\n    this._root.appendChild(secondaryRow);\n    this._container.appendChild(this._root);\n    this.updateView(context);\n  }\n  updateView(context) {\n    var getParamText = param => {\n      if (!param) return \"\";\n      // prefer formatted if available\n      // parametrized inputs may have .formatted (numbers) or .raw (strings)\n      if (param.formatted !== undefined && param.formatted !== null) return String(param.formatted);\n      if (param.raw !== undefined && param.raw !== null) return String(param.raw);\n      return \"\";\n    };\n    var primaryValue = getParamText(context.parameters.primaryValue);\n    var sec1Value = getParamText(context.parameters.secondaryValue1);\n    var sec2Value = getParamText(context.parameters.secondaryValue2);\n    var primaryLabel = getParamText(context.parameters.primaryLabel) || \"\";\n    var secLabel1 = getParamText(context.parameters.secondaryLabel1) || \"\";\n    var secLabel2 = getParamText(context.parameters.secondaryLabel2) || \"\";\n    this._primaryValue.textContent = primaryValue;\n    this._primaryLabel.textContent = primaryLabel;\n    this._secondary1Value.textContent = sec1Value;\n    this._secondary1Label.textContent = secLabel1;\n    this._secondary2Value.textContent = sec2Value;\n    this._secondary2Label.textContent = secLabel2;\n    // Theme classes\n    var root = this._root;\n    var color = context.parameters.customColor && context.parameters.customColor.raw || \"purple\";\n    var bg = context.parameters.backgroundStyle && context.parameters.backgroundStyle.raw || \"gradient\";\n    // remove previous color/bg classes (simple explicit list)\n    root.classList.remove(\"custom-red\", \"custom-green\", \"custom-blue\", \"custom-orange\", \"custom-purple\");\n    root.classList.remove(\"bg-white\", \"bg-clear\", \"bg-gradient\");\n    root.classList.add(\"custom-\".concat(color));\n    root.classList.add(\"bg-\".concat(bg));\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    if (this._root && this._root.parentNode) {\n      this._root.parentNode.removeChild(this._root);\n    }\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MultiNumbControl/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./MultiNumbControl/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DAMultiNumbControl', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAMultiNumbControl);
} else {
	var DA = DA || {};
	DA.DAMultiNumbControl = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAMultiNumbControl;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}