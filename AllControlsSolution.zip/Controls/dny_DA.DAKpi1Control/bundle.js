/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./Kpi1Control/index.ts":
/*!******************************!*\
  !*** ./Kpi1Control/index.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DAKpi1Control: () => (/* binding */ DAKpi1Control)\n/* harmony export */ });\nclass DAKpi1Control {\n  init(context, notifyOutputChanged, state, container) {\n    // create a root wrapper with namespaced class so CSS scoping works consistently\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.Kpi1Control\";\n    this._container = document.createElement(\"div\");\n    this._container.classList.add(\"kpi-stat-container\");\n    this._root.appendChild(this._container);\n    container.appendChild(this._root);\n  }\n  updateView(context) {\n    var kpiValue = context.parameters.kpiValue.formatted || (context.parameters.kpiValue.raw !== null ? context.parameters.kpiValue.raw.toString() : \"N/A\");\n    var kpiLabel = context.parameters.kpiLabel.raw || \"Metric\";\n    var colorTheme = context.parameters.customColor.raw || \"purple\";\n    var bgStyle = context.parameters.backgroundStyle.raw || \"gradient\";\n    var showTrend = context.parameters.showTrend.raw;\n    var classes = [\"kpi-stat-container\"];\n    classes.push(\"custom-\".concat(colorTheme));\n    classes.push(\"bg-\".concat(bgStyle));\n    if (bgStyle !== \"gradient\") {\n      classes.push(\"text-\".concat(colorTheme));\n    }\n    this._container.className = classes.join(\" \");\n    var trendHtml = \"\";\n    if (showTrend === true) {\n      var currentValNum = context.parameters.kpiValue.raw;\n      var trendValNum = context.parameters.trendValue.raw;\n      if (currentValNum !== null && currentValNum !== undefined && trendValNum !== null && trendValNum !== undefined) {\n        var status = \"neutral\";\n        var icon = \"—\";\n        if (currentValNum > trendValNum) {\n          status = \"positive\";\n          icon = \"▲\";\n        } else if (currentValNum < trendValNum) {\n          status = \"negative\";\n          icon = \"▼\";\n        }\n        var trendDisplay = context.parameters.trendValue.formatted || trendValNum.toString();\n        trendHtml = \"\\n                    <div class=\\\"kpi-trend \".concat(status, \"\\\">\\n                        <span class=\\\"kpi-trend-icon\\\">\").concat(icon, \"</span>\\n                        <span>\").concat(trendDisplay, \"</span>\\n                    </div>\\n                \");\n      }\n    }\n    this._container.innerHTML = \"\\n            <div class=\\\"kpi-label\\\">\".concat(kpiLabel, \"</div>\\n            <div class=\\\"kpi-value\\\">\").concat(kpiValue, \"</div>\\n            \").concat(trendHtml, \"\\n        \");\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {}\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Kpi1Control/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./Kpi1Control/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DAKpi1Control', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAKpi1Control);
} else {
	var DA = DA || {};
	DA.DAKpi1Control = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAKpi1Control;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}