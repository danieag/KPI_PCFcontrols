/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./EngagementScorecard/index.ts":
/*!**************************************!*\
  !*** ./EngagementScorecard/index.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DAEngagementScorecard: () => (/* binding */ DAEngagementScorecard)\n/* harmony export */ });\nclass DAEngagementScorecard {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._metricElems = [];\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.EngagementScorecard\";\n    var row = document.createElement(\"div\");\n    row.className = \"metric-row\";\n    this._metricElems = [];\n    for (var i = 0; i < 3; i++) {\n      var item = document.createElement(\"div\");\n      item.className = \"metric\";\n      var value = document.createElement(\"div\");\n      value.className = \"value\";\n      var label = document.createElement(\"div\");\n      label.className = \"label\";\n      var icon = document.createElement(\"span\");\n      icon.className = \"kpi-icon\";\n      icon.setAttribute(\"aria-hidden\", \"true\");\n      icon.innerHTML = this.getIconSvg(i);\n      label.appendChild(icon);\n      item.appendChild(value);\n      item.appendChild(label);\n      row.appendChild(item);\n      this._metricElems.push({\n        value,\n        label,\n        icon\n      });\n    }\n    this._root.appendChild(row);\n    container.appendChild(this._root);\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    var vals = [context.parameters.metric1Value, context.parameters.metric2Value, context.parameters.metric3Value];\n    var labels = [context.parameters.metric1Label, context.parameters.metric2Label, context.parameters.metric3Label];\n    var fmt = p => {\n      if (p == null) return \"\";\n      if (typeof p === \"object\") {\n        var obj = p;\n        if (typeof obj.formatted === \"string\") return obj.formatted;\n        if (obj.raw !== undefined && obj.raw !== null) return String(obj.raw);\n        return \"\";\n      }\n      return String(p);\n    };\n    for (var i = 0; i < 3; i++) {\n      this._metricElems[i].value.textContent = fmt(vals[i]);\n      this._metricElems[i].label.textContent = fmt(labels[i]) || \"\";\n    }\n    // reinsert icons if label text replaced children\n    for (var _i = 0; _i < 3; _i++) {\n      var icon = this._metricElems[_i].icon;\n      var labelEl = this._metricElems[_i].label;\n      if (!labelEl.querySelector('.kpi-icon')) {\n        icon.innerHTML = this.getIconSvg(_i);\n        labelEl.insertBefore(icon, labelEl.firstChild);\n      }\n    }\n    // theme classes\n    var color = context.parameters.colorTheme && context.parameters.colorTheme.raw || \"purple\";\n    var bg = context.parameters.backgroundStyle && context.parameters.backgroundStyle.raw || \"gradient\";\n    this._root.classList.remove(\"custom-red\", \"custom-green\", \"custom-blue\", \"custom-orange\", \"custom-purple\");\n    this._root.classList.remove(\"bg-white\", \"bg-clear\", \"bg-gradient\");\n    this._root.classList.add(\"custom-\".concat(color));\n    this._root.classList.add(\"bg-\".concat(bg));\n    var height = context.parameters.cardHeight && context.parameters.cardHeight.raw;\n    if (height) this._root.style.height = \"\".concat(height, \"px\");\n  }\n  getIconSvg(index) {\n    switch (index) {\n      case 0:\n        // users\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zM8 11c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5C15 14.17 10.33 13 8 13zm8 0c-.29 0-.62.02-.98.05 1.16.84 1.98 1.99 1.98 3.45V19h6v-2.5C23 14.17 18.33 13 16 13z\\\"/></svg>\";\n      case 1:\n        // chart\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M3 13h4v8H3zM10 5h4v16h-4zM17 9h4v12h-4z\\\"/></svg>\";\n      case 2:\n        // trophy / score\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M18 3H6v2a5 5 0 005 5h2a5 5 0 005-5V3zM6 19v2h12v-2a6 6 0 00-12 0z\\\"/></svg>\";\n      default:\n        return '';\n    }\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./EngagementScorecard/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./EngagementScorecard/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DAEngagementScorecard', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAEngagementScorecard);
} else {
	var DA = DA || {};
	DA.DAEngagementScorecard = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAEngagementScorecard;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}