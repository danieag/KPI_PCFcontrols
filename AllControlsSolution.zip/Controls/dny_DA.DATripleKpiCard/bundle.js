/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TripleKpiCard/index.ts":
/*!********************************!*\
  !*** ./TripleKpiCard/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DATripleKpiCard: () => (/* binding */ DATripleKpiCard)\n/* harmony export */ });\nclass DATripleKpiCard {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._items = [];\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.TripleKpiCard\";\n    var row = document.createElement(\"div\");\n    row.className = \"triple-row\";\n    this._items = [];\n    for (var i = 0; i < 3; i++) {\n      var item = document.createElement(\"div\");\n      item.className = \"triple-item\";\n      var value = document.createElement(\"div\");\n      value.className = \"value\";\n      var label = document.createElement(\"div\");\n      label.className = \"label\";\n      var icon = document.createElement(\"span\");\n      icon.className = \"kpi-icon\";\n      icon.setAttribute(\"aria-hidden\", \"true\");\n      icon.innerHTML = this.getIconSvg(i);\n      // place icon before the label text\n      label.appendChild(icon);\n      item.appendChild(value);\n      item.appendChild(label);\n      row.appendChild(item);\n      this._items.push({\n        value,\n        label,\n        icon\n      });\n    }\n    this._root.appendChild(row);\n    container.appendChild(this._root);\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    var vals = [context.parameters.phoneCallsValue, context.parameters.emailsValue, context.parameters.meetingsValue];\n    var labels = [context.parameters.phoneCallsLabel, context.parameters.emailsLabel, context.parameters.meetingsLabel];\n    var fmt = p => {\n      if (p == null) return \"\";\n      if (typeof p === \"object\") {\n        var obj = p;\n        if (typeof obj.formatted === \"string\") return obj.formatted;\n        if (obj.raw !== undefined && obj.raw !== null) return String(obj.raw);\n        return \"\";\n      }\n      return String(p);\n    };\n    for (var i = 0; i < 3; i++) {\n      this._items[i].value.textContent = fmt(vals[i]);\n      this._items[i].label.textContent = fmt(labels[i]) || \"\";\n    }\n    // ensure icon remains (setting label text may have replaced children)\n    // if labels are dynamic keep icons by re-inserting them\n    for (var _i = 0; _i < 3; _i++) {\n      var icon = this._items[_i].icon;\n      var labelEl = this._items[_i].label;\n      // if icon was replaced by setting textContent, re-add it\n      if (!labelEl.querySelector('.kpi-icon')) {\n        icon.innerHTML = this.getIconSvg(_i);\n        labelEl.insertBefore(icon, labelEl.firstChild);\n      }\n    }\n    var bg = context.parameters.backgroundStyle && context.parameters.backgroundStyle.raw || \"gradient\";\n    this._root.classList.remove(\"bg-white\", \"bg-clear\", \"bg-gradient\");\n    this._root.classList.add(\"bg-\".concat(bg));\n  }\n  getIconSvg(index) {\n    // simple inline SVG icons sized to 16x16, use currentColor for fill\n    switch (index) {\n      case 0:\n        // phone\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M6.62 10.79a15.05 15.05 0 006.59 6.59l2.2-2.2a1 1 0 01.94-.27c1.02.25 2.12.39 3.25.39a1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h2.5a1 1 0 011 1c0 1.13.14 2.23.39 3.25a1 1 0 01-.27.94l-2.2 2.2z\\\"/></svg>\";\n      case 1:\n        // email\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M20 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V6a2 2 0 00-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z\\\"/></svg>\";\n      case 2:\n        // meetings / calendar\n        return \"<svg width=\\\"16\\\" height=\\\"16\\\" viewBox=\\\"0 0 24 24\\\" fill=\\\"none\\\" xmlns=\\\"http://www.w3.org/2000/svg\\\"><path fill=\\\"currentColor\\\" d=\\\"M19 4h-1V2h-2v2H8V2H6v2H5a2 2 0 00-2 2v12a2 2 0 002 2h14a2 2 0 002-2V6a2 2 0 00-2-2zm0 14H5V9h14v9z\\\"/></svg>\";\n      default:\n        return '';\n    }\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {};\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TripleKpiCard/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./TripleKpiCard/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DATripleKpiCard', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DATripleKpiCard);
} else {
	var DA = DA || {};
	DA.DATripleKpiCard = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DATripleKpiCard;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}