/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DAValueCard3/index.ts"
/*!*******************************!*\
  !*** ./DAValueCard3/index.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DAValueCard3: () => (/* binding */ DAValueCard3)\n/* harmony export */ });\nclass DAValueCard3 {\n  constructor() {\n    this._items = [];\n  }\n  init(context, notifyOutputChanged, state, container) {\n    container.style.border = \"none\";\n    container.style.padding = \"0\";\n    container.style.margin = \"0\";\n    container.style.background = \"transparent\";\n    container.style.boxShadow = \"none\";\n    container.style.height = \"100%\";\n    container.style.width = \"100%\";\n    container.style.overflow = \"hidden\";\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.DAValueCard3\";\n    var row = document.createElement(\"div\");\n    row.className = \"vc-row\";\n    this._items = [];\n    for (var i = 0; i < 3; i++) {\n      var item = document.createElement(\"div\");\n      item.className = \"vc-item\";\n      var value = document.createElement(\"div\");\n      value.className = \"vc-value\";\n      var label = document.createElement(\"div\");\n      label.className = \"vc-label\";\n      item.appendChild(value);\n      item.appendChild(label);\n      row.appendChild(item);\n      this._items.push({\n        value,\n        label\n      });\n    }\n    this._root.appendChild(row);\n    container.appendChild(this._root);\n  }\n  sanitizeHex(val) {\n    if (!val) return null;\n    var hex = val.trim();\n    if (!hex) return null;\n    if (hex.charAt(0) !== \"#\") hex = \"#\" + hex;\n    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(hex)) return hex;\n    return null;\n  }\n  updateView(context) {\n    var fmt = p => {\n      if (p.formatted) return p.formatted;\n      if (p.raw !== null && p.raw !== undefined) return String(p.raw);\n      return \"\";\n    };\n    var vals = [context.parameters.value1, context.parameters.value2, context.parameters.value3];\n    var labels = [context.parameters.label1, context.parameters.label2, context.parameters.label3];\n    var defaults = [\"Value 1\", \"Value 2\", \"Value 3\"];\n    for (var i = 0; i < 3; i++) {\n      this._items[i].value.textContent = fmt(vals[i]);\n      this._items[i].label.textContent = labels[i].raw || defaults[i];\n    }\n    var color = context.parameters.customColor.raw || \"purple\";\n    var bg = context.parameters.backgroundStyle.raw || \"gradient\";\n    this._root.classList.remove(\"custom-red\", \"custom-green\", \"custom-blue\", \"custom-orange\", \"custom-purple\");\n    this._root.classList.remove(\"bg-white\", \"bg-clear\", \"bg-gradient\");\n    this._root.classList.add(\"custom-\" + color);\n    this._root.classList.add(\"bg-\" + bg);\n    var gradStart = this.sanitizeHex(context.parameters.gradientStartColor.raw);\n    var gradEnd = this.sanitizeHex(context.parameters.gradientEndColor.raw);\n    if (bg === \"gradient\" && gradStart && gradEnd) {\n      this._root.style.background = \"linear-gradient(135deg, \" + gradStart + \" 0%, \" + gradEnd + \" 100%)\";\n    } else {\n      this._root.style.background = \"\";\n    }\n    var accent = this.sanitizeHex(context.parameters.accentColor.raw);\n    for (var _i = 0; _i < 3; _i++) {\n      this._items[_i].value.style.color = bg !== \"gradient\" && accent ? accent : \"\";\n    }\n    var h = context.parameters.cardHeight.raw;\n    if (h && h > 0) {\n      this._root.style.height = h + \"px\";\n      this._root.style.flex = \"\";\n    } else {\n      this._root.style.height = \"\";\n      this._root.style.flex = \"1 1 auto\";\n    }\n    var boldVal = context.parameters.boldValue.raw;\n    var bvWeight = boldVal === true || boldVal === \"true\" ? \"700\" : \"400\";\n    var boldLbl = context.parameters.boldLabel.raw;\n    var blWeight = boldLbl === true || boldLbl === \"true\" ? \"700\" : \"400\";\n    for (var _i2 = 0; _i2 < 3; _i2++) {\n      this._items[_i2].value.style.fontWeight = bvWeight;\n      this._items[_i2].label.style.fontWeight = blWeight;\n    }\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // cleanup\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DAValueCard3/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./DAValueCard3/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DAValueCard3', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAValueCard3);
} else {
	var DA = DA || {};
	DA.DAValueCard3 = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAValueCard3;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}