/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DAValueCard1/index.ts"
/*!*******************************!*\
  !*** ./DAValueCard1/index.ts ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DAValueCard1: () => (/* binding */ DAValueCard1)\n/* harmony export */ });\nclass DAValueCard1 {\n  constructor() {\n    // empty\n  }\n  init(context, notifyOutputChanged, state, container) {\n    // Reset framework container to prevent double-box\n    container.style.border = \"none\";\n    container.style.padding = \"0\";\n    container.style.margin = \"0\";\n    container.style.background = \"transparent\";\n    container.style.boxShadow = \"none\";\n    container.style.height = \"100%\";\n    container.style.width = \"100%\";\n    container.style.overflow = \"hidden\";\n    this._root = document.createElement(\"div\");\n    this._root.className = \"DA.DAValueCard1\";\n    this._valueEl = document.createElement(\"div\");\n    this._valueEl.className = \"vc-value\";\n    this._labelEl = document.createElement(\"div\");\n    this._labelEl.className = \"vc-label\";\n    this._root.appendChild(this._valueEl);\n    this._root.appendChild(this._labelEl);\n    container.appendChild(this._root);\n  }\n  sanitizeHex(val) {\n    if (!val) return null;\n    var hex = val.trim();\n    if (!hex) return null;\n    if (hex.charAt(0) !== \"#\") hex = \"#\" + hex;\n    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(hex)) return hex;\n    return null;\n  }\n  updateView(context) {\n    // Value\n    var v1 = context.parameters.value1;\n    this._valueEl.textContent = v1.formatted ? v1.formatted : v1.raw !== null && v1.raw !== undefined ? String(v1.raw) : \"\";\n    // Label\n    this._labelEl.textContent = context.parameters.label1.raw || \"Value\";\n    // Color theme and background style\n    var color = context.parameters.customColor.raw || \"purple\";\n    var bg = context.parameters.backgroundStyle.raw || \"gradient\";\n    this._root.classList.remove(\"custom-red\", \"custom-green\", \"custom-blue\", \"custom-orange\", \"custom-purple\");\n    this._root.classList.remove(\"bg-white\", \"bg-clear\", \"bg-gradient\");\n    this._root.classList.add(\"custom-\" + color);\n    this._root.classList.add(\"bg-\" + bg);\n    // Custom gradient colors (only apply when background is gradient)\n    var gradStart = this.sanitizeHex(context.parameters.gradientStartColor.raw);\n    var gradEnd = this.sanitizeHex(context.parameters.gradientEndColor.raw);\n    if (bg === \"gradient\" && gradStart && gradEnd) {\n      this._root.style.background = \"linear-gradient(135deg, \" + gradStart + \" 0%, \" + gradEnd + \" 100%)\";\n    } else {\n      this._root.style.background = \"\";\n    }\n    // Accent color override for values on white/clear backgrounds\n    var accent = this.sanitizeHex(context.parameters.accentColor.raw);\n    if (bg !== \"gradient\" && accent) {\n      this._valueEl.style.color = accent;\n    } else {\n      this._valueEl.style.color = \"\";\n    }\n    // Height: 0 = flex, >0 = fixed px\n    var h = context.parameters.cardHeight.raw;\n    if (h && h > 0) {\n      this._root.style.height = h + \"px\";\n      this._root.style.flex = \"\";\n    } else {\n      this._root.style.height = \"\";\n      this._root.style.flex = \"1 1 auto\";\n    }\n    // Bold toggles\n    var boldVal = context.parameters.boldValue.raw;\n    this._valueEl.style.fontWeight = boldVal === true || boldVal === \"true\" ? \"700\" : \"400\";\n    var boldLbl = context.parameters.boldLabel.raw;\n    this._labelEl.style.fontWeight = boldLbl === true || boldLbl === \"true\" ? \"700\" : \"400\";\n  }\n  getOutputs() {\n    return {};\n  }\n  destroy() {\n    // cleanup\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DAValueCard1/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./DAValueCard1/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('DA.DAValueCard1', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAValueCard1);
} else {
	var DA = DA || {};
	DA.DAValueCard1 = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DAValueCard1;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}